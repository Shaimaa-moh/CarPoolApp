import 'Trips.dart';

class Cart {

  List<Trip> tripsInCart = [];
}