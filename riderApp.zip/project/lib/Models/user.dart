//import 'Trips.dart';
class user {
  String name;
  String id;
  //List<Trip> TripReservation;
  user({
    required this.name,
    required this.id,
   // required this.TripReservation,

  });
}

user sampleAppUser =
user(name: "Shaimaa", id: "User1"); //TripReservation: []);