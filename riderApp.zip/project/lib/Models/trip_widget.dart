import 'package:flutter/material.dart';
import 'package:project/Models/Trips.dart';


class TripsListView extends StatelessWidget {
  final List<Trip> trips;
  const TripsListView({super.key, required this.trips});
  @override
  Widget build(BuildContext context) {

    return ListView.builder(
      itemCount: trips.length,
      itemBuilder: (BuildContext context, int index) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Card(
            child: ListTile(
              title: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text(trips[index].Tripname, style: const TextStyle(
                    fontSize: 20,
                  ),),
                  Text('Rate: ${trips[index].rate.toString()}',style: const TextStyle(
                    fontSize: 20,
                  ),),
                ],
              ),
              subtitle : Padding(
                padding: const EdgeInsets.all(5.0),
                child: Center(child: Text('Price: \$${trips[index].price.toString()}',style: const TextStyle(
                  fontSize: 20,
                ),)),
              ),
              trailing:  IconButton(icon: const Icon(Icons.delete), onPressed: () {  },),
                   ),
              ),

        );
        },

    );
  }
}
