class AppUser {
  //return user based our user model
  final String uid;
  AppUser({required this.uid});
}
