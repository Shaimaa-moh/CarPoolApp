import 'dart:core';
class Trip {

  String Tripname;
  double price;
  double rate;

  Trip({
    required this.Tripname,
    required this.price,
    required this.rate,

  });
  static final Trip Trip1 = Trip(
      Tripname: 'Trip1',
      price: 100,
      rate: 5,
  );
  static final Trip Trip2 = Trip(
    Tripname: 'Trip2',
    price: 200,
    rate: 4,
  );
  static final Trip Trip3 = Trip(
    Tripname: 'Trip3',
    price: 120,
    rate: 5,
  );
  static final Trip Trip4 = Trip(
    Tripname: 'Trip4',
    price: 50,
    rate: 5,
  );
}