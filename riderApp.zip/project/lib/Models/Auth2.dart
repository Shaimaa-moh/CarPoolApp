import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';


class AuthServices {
  //an instance of the FirebaseAuth class
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<bool> checkUserExistsInFirestore(String email, String password) async {
    // Ensure your Firestore query is correctly checking for user existence
    try {
      QuerySnapshot query = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: email)
          .get();

      return query.docs
          .isNotEmpty; // Returns true if there are documents matching the email
    } catch (e) {
      // Handle any potential errors during the Firestore query
      print('Error checking user existence: $e');
      return false;
    }
  }

  //Sign up with email and password
  Future<void> signUpWithEmailAndPassword(String email, String password,
      String username, String phone) async {
    try {
      UserCredential userCredential = await _auth
          .createUserWithEmailAndPassword(email: email, password: password);
      User? user = userCredential.user;
      if (user != null) {
        await saveUserData(
            user.uid, email, username, phone); // Save user data to Firestore
      }
    } catch (e) {
      print('Error during sign up: $e');
      throw e;
    }
  }

  //Sign in with email and password
  Future<User?> signInWithEmailAndPassword(String email,
      String password) async {
    try {
      //UserCredential userCredential =
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      //User? user = userCredential.user;
    } catch (e) {
      print('Error during sign in: $e');
      // Handle sign-in errors here.
    }
    return null;
  }

  //sign out
  Future signOut() async {
    try {
      await _auth.signOut();
      return null;
    } catch (e) {
      debugPrint("$e");
      return e;
    }
  }

  Future<void> saveUserData(String Uid, String email, String username,
      String phone) async {
    try {
      await FirebaseFirestore.instance.collection('users').doc(Uid).set({
        'username': username,
        'email': email,
        'phone': phone,

      });
    } catch (e) {
      print('Error saving user data: $e');
      // Handle data saving errors here.
    }
  }

  Future<List<DocumentSnapshot>> fetchData(CollectionReference userRef) async {
    try {
      QuerySnapshot querySnapshot = await userRef.get();
      if (querySnapshot.docs.isNotEmpty) {
        // Return the list of documents that match the query
        return querySnapshot.docs;
      }
    } catch (e) {
      print('Error fetching data: $e');
    }
    // Return an empty list if no documents match the query or if there's an error
    return [];
  }


//var userref = FirebaseFirestore.instance.collection('rides');
//Future<List> fetchdata()async {
//var x = await userref.get();

//List mydoc = x.docs;
//return mydoc;
//}
}
