import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:project/Models/Auth2.dart';
import 'package:project/Screens/PayVisa.dart';
import 'package:project/Screens/ReservationHistory.dart';
List<String> PaymentMethods = ['Cash','Visa'];
String payVal = PaymentMethods.first;
DateTime time_now =DateTime.now();
String time =  time_now.hour.toString().padLeft(2, '0');
final uid = FirebaseAuth.instance.currentUser?.uid;

class TripDetails extends StatefulWidget {
  const TripDetails({super.key});

  @override
  State<TripDetails> createState() => _TripDetailsState();
}

class _TripDetailsState extends State<TripDetails> {
  AuthServices _auth =AuthServices();
  Future<void> updateStatusToPending(List<DocumentSnapshot> documents) async {
    try {
      // Iterate through each document in the list
      for (var doc in documents) {
        // Get the document reference
        var docRef = FirebaseFirestore.instance.collection('rides').doc(doc.id);
        // Update the 'status' field to 'pending'
        await docRef.update({'status': 'pending'});
      }
    } catch (e) {
      print('Error updating status to pending: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    Map Data = ModalRoute.of(context)!.settings.arguments as Map;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Trip details', style: TextStyle(color:Colors.white,
        fontSize: 28,
        fontFamily: 'Courier',),),
        backgroundColor: Colors.grey.shade900,
        centerTitle: true,
        leading: const BackButton(),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(18.0),
          child: Column(
            crossAxisAlignment:CrossAxisAlignment.start,
                 children:[
                     Text('${Data['start']}',style: const TextStyle(fontSize: 20),
                  ),
                   Text('${Data['destination']}',style: const TextStyle(fontSize: 20),
                   ),
                   const SizedBox(
                     height: 15,
                   ),
                   Text('${Data['spots']}' ,style: const TextStyle(fontSize: 20)),
                   const SizedBox(
                     height: 15,
                   ),
                   Text('${Data['price']}' ,style: const TextStyle(fontSize: 20)),
                   const SizedBox(
                     height: 15,
                   ),
                   const Text('Adjust price',style: TextStyle(
                          fontSize: 20,
                          color: Colors.pinkAccent,
                        )),
                   const SizedBox(
                     height: 15,
                   ),
                      const TextField(
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: 'Enter Price',
                        ),
                      ),
                   Text('${Data['date'].toString()}' ,style: const TextStyle(fontSize: 20)),
                   const SizedBox(
                     height: 15,
                   ),

          Row(
            mainAxisAlignment:MainAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.all(10.0),
                child: Text('Payment Method', style: TextStyle(
                  fontSize: 20,
                  color: Colors.pinkAccent,
                ),),
              ),
              DropdownButton(
                  value: payVal,
                  items: PaymentMethods.map((String Value) {
                    return DropdownMenuItem(
                      value: Value,
                      child: Text(Value , style: const TextStyle(
                        fontSize: 18,
                      ),),
                    );
                  }).toList(),
                  onChanged: (String? Value) {
                    setState(() {
                      payVal = Value!;
                    });
                  }),
              ],
                ),

          Center(
            child: SizedBox(
              width: 250,
              height: 100,
              child: Padding(
                padding: const EdgeInsets.all(18.0),
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.indigo,
                        shape: const StadiumBorder(),
                        padding: const EdgeInsets.fromLTRB(20, 12, 20, 12)),
                       onPressed: () async{
                        if(Data['time'].toString()=='7:30 AM') {
                          DateTime rideTime = DateTime(
                              time_now.year, time_now.month, time_now.day + 1,
                              7, 30);
                          DateTime date = DateTime.parse(Data['date']);
                          DateTime reservationDeadline = DateTime(
                              date.year, date.month, date.day, 22, 0);

                          print(time);
                          if (rideTime.isBefore(reservationDeadline)) {
                            print('Reservation done successfully');
                            var userRef = FirebaseFirestore.instance.collection(
                                'rides');
                            List<DocumentSnapshot> fetchedData = await _auth
                                .fetchData(userRef);
                            if (fetchedData.isNotEmpty) {
                              // Update the status to 'pending' for the fetched documents
                              await updateStatusToPending(fetchedData);
                              // Update status for the selected ride
                              await FirebaseFirestore.instance.collection('requests').add({
                                'userID': uid,
                                'RideID': Data['rideId'],
                                'status':Data['status'],

                              });
                              print(
                                  'Status updated to pending for fetched documents.');
                            } else {

                              print('No documents fetched.');
                            }
                          }

                          // Check if the current time allows reservation for the ride at 7:30 the next day
                          else {
                            print(
                                'Reservation for the ride at 7:30 is closed.');
                          }
                        }

                        else if(Data['time'].toString()=='5:30 PM'){
                          DateTime rideTime = DateTime(time_now.year, time_now.month, time_now.day , 5, 30);
                          DateTime date = DateTime.parse(Data['date']);
                          DateTime reservationDeadline = DateTime(date.year, date.month, date.day, 13, 0);
                          print(time);
                          if (rideTime.isBefore(reservationDeadline)) {
                            print('Reservation done successfully');
                            var userRef = FirebaseFirestore.instance.collection('rides');
                            List<DocumentSnapshot> fetchedData = await _auth.fetchData(userRef);
                            if (fetchedData.isNotEmpty) {
                              // Update the status to 'pending' for the fetched documents
                              await updateStatusToPending(fetchedData);
                                // Update status for the selected ride
                              await FirebaseFirestore.instance.collection('requests').add({
                                'userID': uid,
                                'RideID': Data['rideId'],
                                'status':Data['status'],

                              });

                                print(
                                    'Status updated to pending for fetched documents.');
                              } else {
                                print('No documents fetched.');
                              }
                            }
                          }
                          // Check if the current time allows reservation for the ride at 7:30 the next day
                          else {
                            print('Reservation for the ride at 5:30pm is closed.');
                          }



                  Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => const PayVisa(),));
                }, child: const Text('Request',style: TextStyle(color: Colors.white, fontSize: 20,))),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 290,top: 180),
            child: FloatingActionButton(
              onPressed: () {
                Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => const ReservationHistory(),));
              },
              backgroundColor: Colors.white,
              child: const Icon(
                Icons.car_rental,
                color: Colors.pinkAccent,
              ),
            ),
          ),

            ],
          ),
        ),
      ),

    );
  }
}
