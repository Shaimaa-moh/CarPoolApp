import 'package:flutter/material.dart';

List PickUplocations =[
  'Ain Shams to El-Sherouk',' Ain Shams to Naser City','Ain Shams to Rehab','Ain Shams to Helioplis','Ain Shams to Abaysia'
];

List Spots=[
  '2 spots left','5 spots left','3 spots left','0 spots left','5 spots left'
];
List prices=[
  'LE 80','LE 100',
  'LE 120','LE 60','LE 50',
];

class RequestTrip2 extends StatefulWidget {
  const RequestTrip2({super.key});

  @override
  State<RequestTrip2> createState() => _RequestTrip2State();
}

class _RequestTrip2State extends State<RequestTrip2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('PickUp Location',style: TextStyle(
          fontFamily: "Courier",
          fontSize: 28,
        ),),
        backgroundColor: Colors.grey.shade900,
        centerTitle: true,
      ),
      body : ListView.builder(
        itemCount: PickUplocations.length,
        itemBuilder: (context, index){
          return Padding(
              padding: const EdgeInsets.all(10),
              child: Card(
                child: ListTile(title: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text('${PickUplocations[index]}',
                    ),
                    Text('${prices[index]}',
                    ),
                  ],
                ),
                  subtitle: Text('${Spots[index]}'),
                  leading:const Icon(Icons.train_outlined),
                  trailing: IconButton(
                    icon: const Icon(
                      Icons.add,
                    ), onPressed: () {
                  },
                    color: Colors.indigo,
                  ),
                  onTap: () {
                    print('you pressed on ${PickUplocations[index]}');
                    Navigator.pushNamed((context), '/TripDetails', arguments: {
                      'title': "${PickUplocations[index]}","Spots":"${Spots[index]}","Price":"${prices[index]}"});
                  }

                ),

              ),

          );
        },
      ),

    );
  }
}

