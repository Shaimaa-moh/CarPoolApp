
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:project/Screens/SignIn.dart';

import '../Models/Auth2.dart';
import 'ReservationHistory.dart';


class Profile extends StatelessWidget {
  Profile({super.key});

  AuthServices _auth = AuthServices();

  Future<Map<String, dynamic>> fetchUserProfile() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;

    if (uid != null) {
      var userRef = FirebaseFirestore.instance.collection('users').doc(uid);
      var documentSnapshot = await userRef.get();
      return documentSnapshot.data() ?? {};
    }

    return {};
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      //backgroundColor: Colors.deepPurple,
      child: FutureBuilder<Map<String, dynamic>>(

          future: fetchUserProfile(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              var userProfile = snapshot.data!;
              return ListView(
                children:[

                      UserAccountsDrawerHeader(
                      accountName:  Text('username:${userProfile['username']}'),
                      accountEmail:  Text('email:${userProfile['email']}'),
                      currentAccountPicture: CircleAvatar(
                        child: ClipOval(
                          child: Image.network(
                            'https://th.bing.com/th/id/R.fa0ca630a6a3de8e33e03a009e406acd?rik=UOMXfynJ2FEiVw&riu=http%3a%2f%2fwww.clker.com%2fcliparts%2ff%2fa%2f0%2fc%2f1434020125875430376profile.png&ehk=73x7A%2fh2HgYZLT1q7b6vWMXl86IjYeDhub59EZ8hF14%3d&risl=&pid=ImgRaw&r=0',
                            width: 90,
                            height: 90,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),

                      decoration: const BoxDecoration(
                        color: Colors.black,
                        image: DecorationImage(
                          image: NetworkImage(
                              'https://th.bing.com/th/id/R.f93c3ab2519f98ef81063811bcde9306?rik=fiqS7K74mTR4Ow&riu=http%3a%2f%2fupload.wikimedia.org%2fwikipedia%2fcommons%2f1%2f19%2fFanabe_beach_sunset.jpg&ehk=Iq8UOxiebLTHrAw3InbuBnaDbr%2bjcHvCzhsHaetONB4%3d&risl=1&pid=ImgRaw&r=0'),
                          fit: BoxFit.cover,
                        ),
                      ),
                ),
                  IconButton(onPressed: (){
                    Navigator.pushNamed(context, '/EditProfile',arguments: {
                      'username': userProfile['username'],
                      'email': userProfile['email'],
                      'phone':userProfile['phone'],

                    },);
                  }, icon:  Icon(Icons.edit),
                    // Navigator.of(context).push(MaterialPageRoute(builder: (context)=>EditProfile()));
                  ),


                  ListTile(
                      leading: const Icon(Icons.request_page),
                      title: const Text('Trip Requests'),
                      onTap: () => {
                        Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (context) => const ReservationHistory(),))
                      }
                  ),
                  ListTile(
                    leading: const Icon(Icons.wallet),
                    title: const Text('Wallet'),
                    onTap: () {},
                  ),
                  ListTile(
                    leading: const Icon(Icons.settings),
                    title: const Text('Settings'),
                    onTap: () {},
                  ),

                  ListTile(
                    leading: const Icon(Icons.logout),
                    title: const Text('Log out'),
                    onTap: () async {
                      _auth.signOut();
                      Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => const SignIn(),
                      ));
                      // await _auth.signOut();
                    },
                  ),
              ]
              );
            }
            else if (snapshot.hasError) {
              return Text("Error has occured in getting db data");
            }
            else if (snapshot.hasError) {
              return Center(child: Text("Error: ${snapshot.error}"));
            } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return Center(child: Text('No profile data found.'));
            }
            else {
              return CircularProgressIndicator();
            }
          }),
    );
  }
}


