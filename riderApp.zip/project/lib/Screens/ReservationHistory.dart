import 'package:project/Models/Trips.dart';
import 'package:flutter/material.dart';

import '../Models/trip_widget.dart';

class ReservationHistory extends StatefulWidget {

   const ReservationHistory({super.key});
  @override
  State<ReservationHistory> createState() => _ReservationHistoryState();
}

class _ReservationHistoryState extends State<ReservationHistory> {
  @override
  int Num_of_trips=1;
  double price=0.0;


  @override
  Widget build(BuildContext context) {
    List<Trip> trips1 = [
      Trip.Trip1,
      Trip.Trip2,
      Trip.Trip3,
      Trip.Trip4,
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Trips'),
        backgroundColor: Colors.grey.shade900,
      ),
      body:TripsListView (trips: trips1),
    );
  }
}







