import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:project/Models/Auth2.dart';
class test_firestore extends StatefulWidget {
  const test_firestore({super.key});

  @override
  State<test_firestore> createState() => _test_firestoreState();
}

AuthServices mydata = AuthServices();
List mylist = [];
String status = "pending";
String selectedRideId='';
var userRef = FirebaseFirestore.instance.collection('rides');

class _test_firestoreState extends State<test_firestore> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar: AppBar(
    title: const Text('PickUp Location',style: TextStyle(
      fontFamily: "Courier",
      fontSize: 28,
    ),),
    backgroundColor: Colors.grey.shade900,
    centerTitle: true,
    ),
        body: Column(
          children: [
            Expanded(child: FutureBuilder(
                future: mydata.fetchData(userRef),
                builder: (context,snapshot){
                  if(snapshot.hasData){
                    mylist = snapshot.data!;
                    return ListView.builder(
                        itemCount: mylist.length,
                        itemBuilder: (context,index) {
                          return Card(
                            child: ListTile(
                              title: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Column(
                                  //mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text('status : ${mylist[index].data()['status']}'),
                                    Text('Start : ${mylist[index].data()['start']}'),
                                    SizedBox(
                                      height: 15,
                                    ),
                                    Text('Destination : ${mylist[index].data()['destination']}'),
                                  ],
                                ),
                              ),
                              subtitle: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [

                                  Text('Spots available : ${mylist[index].data()['spots']}'),
                                  SizedBox(
                                    height: 15,
                                  ),
                                  Text('Price : ${mylist[index].data()['price']}'),
                                  SizedBox(
                                    height: 15,
                                  ),
                                  Text('date : ${mylist[index].data()['date']}'),
                                  SizedBox(
                                    height: 15,
                                  ),
                                  Text('time : ${mylist[index].data()['time']}'),

                                ],
                              ),
                                onTap: () {
                                  //print('you pressed on ${mydata[''].data()}');
                                  //DateTime dateTime = DateTime.parse(mylist[index].data()['date-time']);
                                  setState(() {
                                    selectedRideId = mylist[index].id;
                                    print(selectedRideId);// Assuming your ride has an 'id' property
                                  });
                                  Navigator.pushNamed(context, '/TripDetails',arguments: {
                                    'status': mylist[index].data()['status'],
                                    'start': mylist[index].data()['start'],
                                    'destination': mylist[index].data()['destination'],
                                    'spots': mylist[index].data()['spots'],
                                    'price': mylist[index].data()['price'],
                                    'date':mylist[index].data()['date'],
                                    'time':mylist[index].data()['time'],
                                    'rideId':selectedRideId,
                                    },);
                              }
                            ),
                          );
                        });
                  }
                  else if(snapshot.hasError){
                    return Text("Error has occured in getting db data");
                  }
                  else{
                    return CircularProgressIndicator();
                  }
                }))
          ],
        ),
      );

  }
}
