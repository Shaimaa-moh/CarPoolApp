
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';


class ProfilePage extends StatefulWidget {


  const ProfilePage({super.key,});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}


class _ProfilePageState extends State<ProfilePage> {
  Future<Map<String, dynamic>> fetchUserProfile() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;

    if (uid != null) {
      var userRef = FirebaseFirestore.instance.collection('drivers').doc(uid);
      var documentSnapshot = await userRef.get();

      return documentSnapshot.data() ?? {};
    }

    return {};
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Column(
          children: [

             Expanded(
              child: FutureBuilder<Map<String, dynamic>>(
                  future: fetchUserProfile(),
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      var userProfile = snapshot.data!;

                      // Render the user profile data here
                      print('User Profile Length: ${userProfile.length}');
                      return SingleChildScrollView(
                         child: Padding(
                           padding: const EdgeInsets.all(70.0),
                           child: Center(
                             child:
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                 children: [

                                     const CircleAvatar(
                                     radius: 130,
                                     backgroundImage: NetworkImage(
                                       'https://groupsorlink.com/wp-content/uploads/2021/07/1140-man-driving-a-car.imgcache.revf9c4f44f3b585ea7b920f79e4f144bd6-1024x588.jpg',
                                     ),
                                     ),
                                     IconButton(onPressed: (){
                                       Navigator.pushNamed(context, '/EditProfile',arguments: {
                                         'username': userProfile['username'],
                                         'email': userProfile['email'],
                                         'phone':userProfile['phone'],

                                       },);
                                     }, icon:  const Icon(Icons.edit),
                                      // Navigator.of(context).push(MaterialPageRoute(builder: (context)=>EditProfile()));
                                  ),

                                   ListTile(
                                  title: Column(

                                    children: [
                                      Text('username: ${userProfile['username']}'),
                                    ],
                                  ),
                                  subtitle: Column(

                                    children: [
                                      Center(
                                        child: Text(
                                              'email: ${userProfile['email']}'),
                                      ),
                                     Text(
                                         'phone: ${userProfile['phone']}'),

                                    ],
                                  ),
                                  // Add more Text widgets for other profile fields

                                   )],
                               ),
                             ),
                         ),

                          );
                    }

                    else if (snapshot.hasError) {
                      return const Text("Error has occured in getting db data");
                    }
                  else if (snapshot.hasError) {
                  return Center(child: Text("Error: ${snapshot.error}"));
                  } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return const Center(child: Text('No profile data found.'));
                  }
                    else {
                      return const CircularProgressIndicator();
                    }
                  }),
            )
            ],
        )
    );
  }
}
