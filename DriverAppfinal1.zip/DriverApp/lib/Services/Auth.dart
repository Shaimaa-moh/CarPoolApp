import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';


class AuthServices {
  //an instance of the FirebaseAuth class
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<bool> checkUserExistsInFirestore(String email, String password) async {
    // Ensure your Firestore query is correctly checking for user existence
    // This method should not rely on the user's password for checking existence
    // It should only rely on the email for this purpose
    try {
      QuerySnapshot query = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: email)
          .get();

      return query.docs.isNotEmpty; // Returns true if there are documents matching the email
    } catch (e) {
      // Handle any potential errors during the Firestore query
      print('Error checking user existence: $e');
      return false;
    }
  }

  //Sign up with email and password
  Future<void> signUpWithEmailAndPassword(String email, String password ,String username ,String phone) async {
    try {
      UserCredential userCredential = await _auth.createUserWithEmailAndPassword(email: email, password: password);
      User? user = userCredential.user;

      if (user != null) {
        await saveUserData(user.uid, email,username,phone); // Save user data to Firestore
      }
    } catch (e) {
      print('Error during sign up: $e');
      rethrow;
    }
  }

  //Sign in with email and password
  Future<User?> signInWithEmailAndPassword(String email, String password) async {
    try {
      UserCredential userCredential = await FirebaseAuth.instance
          .signInWithEmailAndPassword(email: email, password: password);
      //User? user = userCredential.user;
      //return userCredential.user;

    } catch (e) {
      print('Error during sign in: $e');
      // Handle sign-in errors here.
    }
    return null;
  }


  //sign out
  Future signOut() async {
    try {
      await _auth.signOut();
      return null;
    } catch (e) {
      debugPrint("$e");
      return e;
    }
  }

  Future<void> saveUserData(String Uid, String email, String username ,String phone) async {

    try {
      await FirebaseFirestore.instance.collection('drivers').doc(Uid).set({
        'username':username,
        'email': email,
        'phone': phone,

      });
    } catch (e) {
      print('Error saving user data: $e');
      // Handle data saving errors here.
    }

  }

  Future<void> saveRideData(String status,String start, String destination , String spots , String price ,String date , String time) async {
    try {
      await FirebaseFirestore.instance.collection('rides').add({
        'status':status,
        'start': start,
        'destination': destination,
        'spots': spots,
        'price':price,
        'date':date,
        'time':time,
      });
    } catch (e) {
      print('Error saving user data: $e');
      // Handle data saving errors here.
    }
  }


}


