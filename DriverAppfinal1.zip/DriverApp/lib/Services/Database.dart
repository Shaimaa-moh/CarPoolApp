import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

import '../Driver.dart';

class Databasev2 {
  Database? mydatabase;

  Future<Database?> checkdata() async {
    if (mydatabase == null) {
      mydatabase = await creating();
      return mydatabase;
    } else {
      return mydatabase;
    }
  }

  int Version = 2;
  creating() async {
    String databasepath = await getDatabasesPath();
    String mypath = join(databasepath, 'mynewdatafile2.db');
    Database mydb =
    await openDatabase(mypath, version: Version, onCreate: (db, version) {
      db.execute('''
      CREATE TABLE drivers (
        id INTEGER PRIMARY KEY,
        name TEXT,
        email TEXT,
        phone TEXT,
        carModel TEXT,
        licenseNumber TEXT
      )
    ''');
    });
    return mydb;
  }
  Future<int?> insertDriver(Driver driver) async {
    final db = mydatabase;
    return await db?.insert('drivers', driver.toMap());
  }


  isexist() async {
    String databasepath = await getDatabasesPath();
    String mypath = join(databasepath, 'mynewdatafile2.db');
    await databaseExists(mypath) ? print("it exists") : print("not exist");
  }

  reading(sql) async {
    Database? somevar = await checkdata();
    var myesponse = somevar!.rawQuery(sql);
    return myesponse;
  }

  write(sql) async {
    Database? somevar = await checkdata();
    var myesponse = somevar!.rawInsert(sql);
    return myesponse;
  }

  Future<void> updateDriverProfile(Driver updatedDriver) async {
    try {
      final db = mydatabase;

      print('Before update: ${updatedDriver.toMap()}');

      int? updatedRows = await db?.update(
        'drivers',
        updatedDriver.toMap(),
        where: 'id = ?',
        whereArgs: [updatedDriver.id],
      );

      print('Updated rows: $updatedRows');

    } catch (e) {
      print('Error updating driver: $e');
    }
  }
  delete(sql) async {
    Database? somevar = await checkdata();
    var myesponse = somevar!.rawDelete(sql);
    return myesponse;
  }

}