
import 'package:flutter/material.dart';
import 'package:date_time_picker/date_time_picker.dart';
import 'Services/Auth.dart';


//DateTime selectedDateTime = DateTime.now();
String _selectedDate ='';

List<String> Start = ['Naser City', 'fifth settelment', 'Rehab ', 'Obour' ,'Stadium','Sheraton','Maadi','Ahram','ain shams gate 3','ain shams gate 4'];
String startLoc = Start.first;

List<String> Destination = ['fifth settelment','Naser City','Stadium','Sheraton','Maadi','Ahram','ain shams gate 3','ain shams gate 4','Rehab ', 'Obour' ,];
String destLoc = Destination.first;

List <String> tripTime=['7:00 AM','5:30 PM'];
String trip_start=tripTime.first;
String status = "accepting" ;
final AuthServices _auth = AuthServices();

class OfferRide extends StatefulWidget {
  const OfferRide({super.key});

  @override
  State<OfferRide> createState() => _OfferRideState();
}

class _OfferRideState extends State<OfferRide> {



  final TextEditingController _location = TextEditingController();
  final TextEditingController _spots = TextEditingController();
  final TextEditingController _price = TextEditingController();

@override
  void initState() {
  super.initState();
  // Check if _selectedDate is empty, then set it to the current date
  if (_selectedDate.isEmpty) {
    DateTime currentDate = DateTime.now();
    setState(() {
      _selectedDate =
      '${currentDate.year}-${currentDate.month.toString().padLeft(2, '0')}-${currentDate.day.toString().padLeft(2, '0')}';
    });
  }
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Offer Ride',style: TextStyle(
          fontSize: 25,color: Colors.deepPurple
        )),
        leading: const BackButton(),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(18.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
               Text('Status : $status',style: const TextStyle(
                fontSize: 20,
              )),
              const SizedBox(
                height: 15,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children :[

                const Text('Start:',style: TextStyle(
                  fontSize: 20,
                )),
                  const SizedBox(
                    width: 10,
                  ),
                  DropdownButton<String>(
                      value: startLoc,
                      items: Start.map((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value,style: const TextStyle(
                          color: Colors.black,)),
                      );
                    }).toList(),
                    onChanged: (String? Value)  {
                      setState(() {
                        startLoc = Value!;
                      });
                    }
                  ),

                ]
              ),

              const SizedBox(
                height: 20,
              ),

              Row(
                children: [
                  const Text('Destination :',style: TextStyle(
                    fontSize: 20,
                  )),
                  const SizedBox(
                    width: 10,
                  ),
              DropdownButton<String>(
                value: destLoc,
                  items: Destination.map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value , style: const TextStyle(
                            color: Colors.black,
                    )));
                  }).toList(),
                  onChanged: (String? Value)  {
                    setState(() {
                      destLoc = Value!;
                    });
                  }
              ),
                ],
              ),
              const SizedBox(
                height: 20,
              ),

              TextFormField(
                controller: _spots,
                cursorColor: Colors.deepPurple,
                    decoration:  const InputDecoration(
                      hintText: 'Number of spots',
                    ),

                    onChanged: (Value)  {
                      setState(() {
                        _spots.text = Value;
                      });
                }
                  ),
              const SizedBox(
                height: 20,
              ),

              TextFormField(
                controller: _price,
                cursorColor: Colors.deepPurple,
                decoration: const InputDecoration(
                  hintText: 'Adjust Price',

                ),
                onChanged: (Value) {
                  setState(() {
                    _price.text = Value;
                  });
                }
              ),


              const SizedBox(
                height: 20,
              ),

                DateTimePicker(
                  type: DateTimePickerType.date,
                  dateMask: 'd MMM, yyyy',
                  initialValue: DateTime.now().toString(),
                  icon: const Icon(Icons.event),
                  // initialValue or controller.text can be null, empty or a DateTime string otherwise it will throw an error.
                  dateLabelText: 'Select Date',
                  firstDate: DateTime(1995),
                  lastDate: DateTime.now()
                      .add(const Duration(days: 365)), // This will add one year from current date
                  validator: (value) {
                    return null;
                  },
                  onChanged: (val) async {
                    print(val);
                    //DateTime parsedDateTime = DateTime.parse(val);
                    setState(() {
                      _selectedDate = val;
                      print(_selectedDate);
                      // Update the selected DateTime
                    });

                  },

                  onSaved: (val) => print(val),
                ),
                const SizedBox(
                  height: 15,
                ),
                Row(
                  children: [
                    const Text('Time',style: TextStyle(
                      fontSize: 20,
                    )),
                    const SizedBox(
                      width: 15,
                    ),
                    DropdownButton <String>(items:
                      tripTime.map((String value) {
                        return DropdownMenuItem<String>(
                            value: value,
                            child: Text(value , style: const TextStyle(
                              color: Colors.black,
                            )));}).toList(),
                        value:trip_start ,
                        onChanged: (val){
                      setState(() {
                        trip_start=val!;
                      });
                        }),
                  ],
                ),

               const SizedBox(
                height: 15,
              ),
              ElevatedButton(onPressed: () async  {
                if (startLoc == 'ain shams gate 3' ||
                    startLoc == 'ain shams gate 4' ||
                    destLoc == 'ain shams gate 3' ||
                    destLoc == 'ain shams gate 4') {
                      print('Either start or destination is Ain Shams Gate 3 or 4');
                      }

                else {
                  print('Neither start nor destination is Ain Shams Gate 3 or 4');
                  }
                    String start = startLoc;
                    String destination = destLoc;
                    String spots = _spots.text;
                    String price = _price.text;
                    String date = _selectedDate;
                    String time = trip_start;
                    // Save ride data to Firestore
                    await _auth.saveRideData(status, start, destination, spots, price, date,time);
                    ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                    content: Text('Ride data saved successfully!'),
                    ),
                    );
                setState(() {
                  _spots.clear();
                  _price.clear();

                  // Reset other variables if needed
                });

                    },

              child: const Text('Save',style: TextStyle(
                fontSize: 20,
              )),)

                ],
              ),


          ),
        ),
      );

  }
}
