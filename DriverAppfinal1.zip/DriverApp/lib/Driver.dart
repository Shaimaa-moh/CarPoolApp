

class Driver {
  int? id;
  String name;
  String email;
  String Phone;
  String CarModel;
  String licenseNumber;

  // Add other driver attributes as needed

  Driver({
    this.id,
    required this.name,
    required this.email,
    required this.Phone,
    required this.CarModel,
    required this.licenseNumber,
    // Add other constructor parameters for driver attributes
  });

  // Convert a Driver object into a Map for database operations
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'phone': Phone,
      'Car Model': CarModel,
      'licenseNumber': licenseNumber,
      // Map other attributes as needed
    };
  }

  // Create a Driver object from a Map received from the database
  factory Driver.fromMap(Map<String, dynamic> map) {
    return Driver(
      id: map['id'],
      name: map['name'],
      email: map['email'],
      Phone: map ['Phone'],
      CarModel: map['CarModel'],
      licenseNumber: map['licenseNumber'],
      // Retrieve other attributes from the map
    );
  }

}
