package com.example.driverapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
